import java.util.ArrayList;
import java.util.Arrays;

public class Tour extends Carte {

	private int points;
	private ArrayList<String[]> combinaison;
	private Effet effet;

	public Tour(ArrayList<String[]> combinaison, int points, String nom, String img, boolean visibilite) {
		super(nom, img, visibilite);
		this.combinaison = combinaison;
		this.points = points;
	}
	
	public Tour(ArrayList<String[]> combinaison, int points, String nom, String effet) {
		super(nom);
		this.combinaison = combinaison;
		this.points = points;
		switch (effet) {
			case "1":
				this.effet = Effet.PENALITE_SCORE;
				break;
			case "2":
				this.effet = Effet.CHANGEMENT_SENS;
				break;
			case "3":
				this.effet = Effet.INTERDICTION;
				break;
			case "4":
				this.effet = Effet.FIN;
				break;
			default:
				this.effet = null;
				break;
		}
	}

	public ArrayList<String[]> getCombinaison() {
		return this.combinaison;
	}

	public int getPts() {
		return this.points;
	}

	public Effet getEffet() {
		return this.effet;
	}

	@Override
	public String toString() {
		StringBuffer combi = new StringBuffer();
		for (String[] s : this.combinaison) {
			combi.append(Arrays.toString(s) + "  ");
		}
		String effet =  this.effet == null ? "aucun" : this.effet.getDesc();

		return "######### TourDeMagie #########\n" +
				"# score : "  + points +
				"\n# combinaison : " + combi +
				"\n# nom : " + nom +
				"\n# effet : " + effet + //TODO: afficher l'effet que lorsque la variante est activée
				"\n##############################";
	}
}
