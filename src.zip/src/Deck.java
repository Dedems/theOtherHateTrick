import java.util.Collections;
import java.util.LinkedList;

public class Deck {
	private LinkedList<Tour> tas;
	
	public Deck() {
		this.tas = new LinkedList<Tour>();
	}
	
	public void addTour(Tour t) {
		this.tas.add(t);
	}
	
	public Tour popTour() {
		return this.tas.pop();
	}

	public Tour getFirst() {
		return this.tas.getFirst();
	}

	public int getSize() {
		return this.tas.size();
	}
	
	public void pushTour(Tour t) {
		this.tas.push(t);
	}
	
	public Tour peekTour() {
		return this.tas.peek();
	}
	
	public Tour getLast() {
		return this.tas.getLast();
	}
	
	public void initDeck (LinkedList<Carte> tours) {
		Carte carteSpecial = tours.getLast();
		Collections.shuffle(tours);
		Collections.swap(tours, Partie.NB_TOUR-1, tours.indexOf(carteSpecial));
		for (Carte tour : tours){
			if (tour instanceof Tour) {
				Tour tourDeMagie = (Tour) tour;
				this.tas.add(tourDeMagie);
			}
		}
	}
}
