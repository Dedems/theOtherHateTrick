import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;

public class Humain extends Joueur {

	public Humain(int age, String nom) {
		super(age, nom);
	}

	private int choisirValeur(String msg) {
		Scanner s = new Scanner(System.in);
		int valeur;
		System.out.println(msg);
		do {
			String res = s.next();
			if (!res.equals("0") && !res.equals("1")) {
				valeur = 100;
			} else {
				valeur = Integer.parseInt(res);
			}
		}while(valeur != 0 && valeur != 1);
		return  valeur;
	}

	@Override
	public int choisirTour() {
		return this.choisirValeur(this.getNom() + " voulez vous jouer le tour visible ? Oui:0 | Non:1");
	}

	@Override
	public int choisirSaCarteAEchanger() {
		return this.choisirValeur(this.getNom() + " laquelle de vos cartes voulez vous échanger ? Gauche:0 | Droite:1");
	}

	@Override
	public Joueur choisirAdv(HashMap<Integer,Joueur> listeJoueurs) {
		StringBuffer sb = new StringBuffer();
		StringBuffer sb2 = new StringBuffer();
		System.out.println(this.getNom() + " avec qui voulez vous echanger votre carte ?\n ");
		Scanner s = new Scanner(System.in);

		for (Map.Entry<Integer, Joueur> entry : listeJoueurs.entrySet()) {
			Joueur j = entry.getValue();
			sb.append(j.afficher(this)+"\n");
			sb2.append(entry.getKey()+":Pour "+j.getNom()+"\n");
		}
		System.out.println(sb.toString()+"\n"+sb2.toString());
		Joueur choixAdv;
		do {
			int pos;
			try {
				pos = Integer.parseInt(s.next());
			} catch (NumberFormatException n) {
				pos = 100;
			}
			choixAdv = listeJoueurs.get(pos);
		}while(choixAdv == null);

		return choixAdv;
	}

	@Override
	public int choisirAccessoireAdv(String nomAdv) {
		return this.choisirValeur("Quelle carte de " + nomAdv + " voulez vous échanger avec la votre ? Gauche:0 | Droite:1");
	}

	@Override
	public int choisirPosAccessoirePassePasse() {
		Scanner s = new Scanner(System.in);
		System.out.println("Veuillez choisir la carte à mettre au centre parmis vos deux accessoires\n" +
				"et la carte du millieu afficher ci-dessus. Votre carte Gauche:0 | Droite:1 | Milieu:2");
		int pos;
		do {
			String res = s.next();
			if (!res.equals("0") && !res.equals("1") && !res.equals("2")) {
				pos = 100;
			} else {
				pos = Integer.parseInt(res);
			}
		} while(pos != 2 && pos != 1 && pos != 0);

		return pos;
	}

	@Override
	public void subirPenalite() {
		System.out.println("Vous n'avez malheuresement pas réussi de tour de magie,");
		if (!this.getMain().get(0).isVisible() && !this.getMain().get(1).isVisible()) {
			this.getMain().get(
					this.choisirValeur("veuillez choisir une de vos carte à rendre visible. Gauche:0 | Droite:1")
			).retourner();
		} else if (this.getMain().get(0).isVisible() && !this.getMain().get(1).isVisible()) {
			System.out.println("Votre carte gauche étant visible, votre carte droite est retournée.");
			this.getMain().get(1).retourner();
		} else if (!this.getMain().get(0).isVisible() && this.getMain().get(1).isVisible()) {
			System.out.println("Votre carte droite étant visible, votre carte gauche est retournée.");
			this.getMain().get(0).retourner();
		} else {
			System.out.println("Vos deux cartes étant visibles, pas de pénalité supplémentaire.");
		}
	}
}
