import java.util.*;

public class Partie {

	private ArrayList<Joueur> joueurs;
	private ArrayList<Deck> decks;
	private Accessoire carteMilieu;
	public static final int NB_JOUEURS_MAX = 3;
	public static int NB_TOUR = 10;
	private boolean enCours;
	private int echecTourFinal;
	private int variante;

	public Partie() {
		this.joueurs = new ArrayList<Joueur>();
		this.decks = new ArrayList<Deck>(2);
		for (int i = 0; i < 2; i++) {
			this.decks.add(new Deck());
		}
		this.enCours = false;
		this.echecTourFinal = 0;
		this.variante = 0;
	}

	public HashMap<Integer,Joueur> afficherJoueursExcept(Joueur j) {
		HashMap<Integer,Joueur> autres = new HashMap<Integer, Joueur>();
		for (int i = 0; i < this.joueurs.size(); i++) {
			Joueur autre = this.joueurs.get(i);
			if ( autre != j ) {
				autres.put(i, autre);
			}
		}

		return autres;
	}

	public Deck getFreeDeck() {
		return this.decks.get(0);
	}

	public Accessoire getCarteMilieu() {
		return this.carteMilieu;
	}
	
	public Deck getDeckCimetiere() {
		return this.decks.get(1);
	}
	
	public void distribuerCartes(LinkedList<Carte> props) {
		Collections.shuffle(props);
		while (props.size() > 1) {
			for (Joueur j : this.joueurs) {
				j.prendreCarte((Accessoire) props.pop());
			}
		}
		
		this.carteMilieu = (Accessoire) props.pop();
	}

	public void preparerJoueur() {
		Scanner s = new Scanner(System.in);
		int nbJoueur;
		String res;
		String botLevel;
		System.out.println("Combien de joueurs êtes-vous ? ("+Partie.NB_JOUEURS_MAX+" max)");
		res = s.next();
		if (!res.equals("0") && !res.equals("1") && !res.equals("2") && !res.equals("3")) { //TODO mieu contrôler données entrée.
			nbJoueur = 1;
		} else {
			nbJoueur = Integer.parseInt(res);
		}

		int age;
		String nom;

//		if (nbJoueur > Partie.NB_JOUEURS_MAX) {
//			nbJoueur = Partie.NB_JOUEURS_MAX;
//		} else if(nbJoueur < 0) {
//			nbJoueur = 0;
//		}

		for (int i = 0; i < Partie.NB_JOUEURS_MAX; i++) {
			if (i < nbJoueur) {
				System.out.println("Joueur "+i+" Comment vous appelez vous ?");
				nom = s.next();
				System.out.println("Joueur "+i+" quel âge avez-vous ?");
				try {
					age = Integer.parseInt(s.next());
				} catch (NumberFormatException n) {
					age = 100;
				}

				if (age > 100 || age < 10) {
					age = 100;
				}
				this.joueurs.add(new Humain(age, nom));
			} else {
				System.out.println("Quel niveau donner au Bot "+i+" ? - 1:Facile | 2:Moyen"/* | 3:Difficile"*/);
					botLevel = s.next();
					if (!botLevel.equals("1") && !botLevel.equals("2")) {
						botLevel = "2";
					}

				this.joueurs.add(new Bot("Bot "+i, Integer.parseInt(botLevel)));
			}
		}
		Collections.sort(this.joueurs, Joueur.AgeComparator);
	}

	public int getJoueurSuivant(Joueur j) {
		int index = this.joueurs.indexOf(j);
		if (index == 2) {
			index = 0;
		} else {
			index++;
		}

		return index;
	}

	public boolean isSuccess (Joueur j) {
		boolean res = false;
		String[][] combiJ = {
				{j.getMain().get(0).getNom(), j.getMain().get(1).getNom()},
				{j.getMain().get(1).getNom(), j.getMain().get(0).getNom()}
		};
		ArrayList<String[]> combis = this.getDeckCimetiere().getFirst().getCombinaison();
		for (int i = 0; i < combis.size() && !res; i++) {
			res = Arrays.equals(combis.get(i), combiJ[0]) || Arrays.equals(combis.get(i), combiJ[1]);
		}
		this.verifierFinDePartie(res);

		return res;
	}

	private void verifierFinDePartie(boolean res) {
		//System.out.println(this.getDeckCimetiere().getFirst().getNom());
		if (this.getDeckCimetiere().getFirst().getEffet() == Effet.FIN) {
			if (res) {
				System.out.println("Et pas n'importe quel tour.. L'AUTRE COUP DU CHAPEAU !!!!");
				this.enCours = false;
			} else {
				this.echecTourFinal++;
				if (this.echecTourFinal >= 3) {
					System.out.println("Dommage !! Personne n'a réussi à faire l'autre coup du chapeau..");
					this.enCours = false;
				}
			}
		}
	}

	public void piocher() {
		Tour premiereCarteJouable = this.getFreeDeck().popTour();
		premiereCarteJouable.retourner();
		this.getDeckCimetiere().pushTour(premiereCarteJouable);
	}

	public void preparerPartie() {
		//TODO: singleton scanner?
		Scanner s = new Scanner(System.in);
		System.out.println("Voulez vous ajouter l'extension de carte au set de base ? Oui | Non");
		//TODO: Ajouter plus de carte ?
		boolean extension = s.next().equals("Oui");
		System.out.println("Avec quelle variante voulez vous jouer ? 0: De base | 1: Les effets");
		//TODO: Ajouter une seconde variante. {Idée : Avoir 3 cartes du milieu, donc ajouté 2 props en +}
		if (s.next().equals("1")) {
			this.variante = 1;
//			Partie.NB_TOUR = 10; TODO: le mettre pour extension et non variante
		}
		ArrayList<LinkedList<Carte>> jeuDeCartes = Carte.loads(extension);
		this.getFreeDeck().initDeck(jeuDeCartes.get(0));
		this.distribuerCartes(jeuDeCartes.get(1));
		this.piocher();
		this.enCours = true;
	}

	public void afficherClassement() {
		Collections.sort(this.joueurs, Joueur.ScoreComparator);
		System.out.println("\n\n\n========================= CLASSEMENT =========================\n");
		for (Joueur j : this.joueurs) {
			System.out.println("# "+ j.getNom()+" : "+j.getScore()+" pts \n");
		}
		System.out.println("\n==============================================================\n");
	}

	public void fairePassePasse(Joueur j) {
		int pos = j.choisirPosAccessoirePassePasse();
		j.getMain().get(0).setVisible(false);
		j.getMain().get(1).setVisible(false);
		if (pos != 2) {
			Accessoire temp = j.getMain().remove(pos);
			j.getMain().add(pos, this.carteMilieu);
			this.carteMilieu = temp;
		}
		j.addPoints(this.getDeckCimetiere().popTour().getPts());
		if (this.getDeckCimetiere().getSize() == 0) {
			this.piocher();
		}
	}

	public void changementSens(Joueur j) {
		System.out.println("/!\\ Changement de sens /!\\");
		int index = this.joueurs.indexOf(j);
		int pos1 = 0;
		int pos2 = 1;
		if (index == 0) {
			pos1 = 1;
			pos2 = 2;
		} else if (index == 1) {
			pos2 = 2;
		}
		Collections.swap(this.joueurs, pos1, pos2);
	}

	public void penaliser(Joueur j) {
		Joueur autre = this.joueurs.get(this.getJoueurSuivant(j));
		System.out.print(j.getNom()+" vous faîtes perdre 2pts à "+autre.getNom()+" qui passe de "+autre.getScore());
		autre.addPoints(-2);
		System.out.println(" à "+autre.getScore());
	}

	public void interdireJouer(Joueur j) {
		Joueur autre = this.joueurs.get(this.getJoueurSuivant(j));
		System.out.println(j.getNom()+" vous bloquez le tour à "+autre.getNom());
		autre.setPenalite(true);
	}
	
	private ArrayList<Joueur> getJoueurs() {
		return this.joueurs;
	}

	public void jouer(Joueur j) {
		System.out.println(j.afficher(j));
		System.out.println(this.getDeckCimetiere().getFirst());
		if (this.getFreeDeck().getSize() == 0) {
			System.out.println("La pioche étant vide, vous n'avez plus le choix du tour.");
		} else if (j.choisirTour() == 1) {
			this.piocher();
			System.out.println(this.getDeckCimetiere().getFirst());
		}
		Joueur joueurAdv = j.choisirAdv(this.afficherJoueursExcept(j));
		j.echangerAccessoire(j.choisirSaCarteAEchanger(), j.choisirAccessoireAdv(joueurAdv.getNom()), joueurAdv);
		System.out.println(j.afficher(j));
		if (this.isSuccess(j)) {
			System.out.println("*************" + j.getNom() + " A REUSSI UN TOUR ! TADAAAAA***************");
			if (variante == 1 && this.getDeckCimetiere().getFirst().getEffet() != null) {
				switch (this.getDeckCimetiere().getFirst().getEffet()) {
					case CHANGEMENT_SENS:
						this.changementSens(j);
						break;
					case INTERDICTION:
						this.interdireJouer(j);
						break;
					case PENALITE_SCORE:
						this.penaliser(j);
						break;
					default:
						break;
				}
			}
			if (this.enCours) {
				System.out.println("La carte du centre est : " + this.getCarteMilieu());
				this.fairePassePasse(j);
			} else {
				j.addPoints(this.getDeckCimetiere().popTour().getPts());
			}
		} else {
			if (this.enCours) {
				j.subirPenalite();
			} else {
				if (this.echecTourFinal == 3) {
					this.penaliserMalchanceux();
				}
			}
		}
	}

	public void penaliserMalchanceux() { //TODO: Après l'ajout de la carte Joker, rajouter une penalité pour le dernier ayant cette carte de -5pts
		System.out.println("===============Pas de chance pour les joueurs qui possédaient \"Le chapeau\" et \"L'autre lapin\" qui perdent 3pts!===============");
		Iterator<Joueur> it = this.joueurs.iterator();
		while (it.hasNext()) {
			Joueur j = it.next();
			for (int i = 0; i < j.getMain().size(); i++)
			if (j.getMain().get(i).getNom().equals("Le chapeau") || j.getMain().get(i).getNom().equals("L'autre lapin")) {
				j.addPoints(-3);
			}
		}
	}

	public boolean estEnCours() {
		return this.enCours;
	}

	public static void main(String[] args) {
		Partie partie = new Partie();
		int nbTour = 1;
		partie.preparerJoueur();
		partie.preparerPartie();

		while (partie.estEnCours()) {
			System.out.println("+++++++++++ TOUR "+nbTour+" +++++++++++++");
			Iterator<Joueur> it = partie.getJoueurs().iterator();
			while (it.hasNext() && partie.estEnCours()) {
				Joueur j = it.next();
				if (!j.getPenalite()) {
					System.out.println("~~~~~~~~~~~~~~~~DEBUT JOUEUR " + j.getNom() + "~~~~~~~~~~~~~~~~~~~~");
					partie.jouer(j);
					System.out.println("~~~~~~~~~~~~~~~~FIN JOUEUR " + j.getNom() + "~~~~~~~~~~~~~~~~~~~~");
				} else {
					System.out.println("~~~~~~~~~~~~~~~~INTERDIT DE JOUER " + j.getNom() + "~~~~~~~~~~~~~~~~~~~~");
					j.setPenalite(false);
				}
			}
			nbTour++;
		}
		partie.afficherClassement();
	}
}
