import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

abstract class Joueur {

	private String nom;
	private int age;
	private int score;
	private ArrayList<Accessoire> main;
	private boolean penalite;
	
	public Joueur(int age, String nom) {
		this.nom = nom;
		this.age = age;
		this.score = 0;
		this.main = new ArrayList<Accessoire>(2);
		this.penalite = false;
	}

	public boolean getPenalite() {
		return this.penalite;
	}

	public void setPenalite(boolean penalite) {
		this.penalite = penalite;
	}

	public static Comparator<Joueur> ScoreComparator = new Comparator<Joueur>() {
		@Override
		public int compare(Joueur o1, Joueur o2) {
			int res = 1;
			if (o1.score == o2.score) {
				res = 0;
			} else if (o2.score > o1.score) {
				res = -1;
			}
			return res;
		}
	};

	public static Comparator<Joueur> AgeComparator = new Comparator<Joueur>() {
		@Override
		public int compare(Joueur o1, Joueur o2) {
			int res = 1;
			if (o1.age == o2.age) {
				res = 0;
			} else if (o2.age > o1.age) {
				res = -1;
			}
			return res;
		}
	};

	public String getNom() {
		return nom;
	}

	public int getScore() {
		return score;
	}

	public void addPoints(int pts) {
		this.score += pts;
	}

	public ArrayList<Accessoire> getMain() {
		return main;
	}

	public void prendreCarte(Accessoire a) {
		this.main.add(a);
	}

	@Override
	public String toString() {
		return "########### Joueur ###########   \n# nom   : " + nom + "\n# age   : " + age + "\n# score : " + score;
	}

	public String afficher(Joueur j) {
		if (this == j) {
			return this.toString() + "\n# main  : " + main + "\n##############################";
		} else {
			StringBuffer sb = new StringBuffer("[");
			for (int i = 0; i < this.main.size(); i++) {
				if (i == 1) {
					sb.append(",");
				}
				Accessoire prop = this.main.get(i);
				if (prop.isVisible()) {
					sb.append(prop.getNom());
				} else {
					sb.append(" Carte caché");
				}
			}
			sb.append("]");
			return this.toString()+"\n# main  : " +sb.toString() +"\n##############################";
		}
	}

	abstract public int choisirTour();

	abstract public int choisirSaCarteAEchanger();

	abstract public Joueur choisirAdv(HashMap<Integer,Joueur> listeJoueurs);

	abstract public int choisirAccessoireAdv(String nomAdv);

	abstract public int choisirPosAccessoirePassePasse();

	abstract public void subirPenalite();

	public void echangerAccessoire(int posPremierAccess, int posSecondAccess, Joueur j) {
		Accessoire temp = this.main.get(posPremierAccess);
		this.main.set(posPremierAccess, j.main.get(posSecondAccess));
		j.main.set(posSecondAccess, temp);
	}
}
