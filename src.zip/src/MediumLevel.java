import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MediumLevel implements LevelStrategy {
    @Override
    public int choisirTour() {
        return new Random().nextInt(2);
    }

    @Override
    public int choisirSaCarteAEchanger() {
        return new Random().nextInt(2);
    }

    @Override
    public Joueur choisirAdv(HashMap<Integer,Joueur> listeJoueurs) {
        StringBuffer sb = new StringBuffer();
        StringBuffer sb2 = new StringBuffer();
        Object[] keys = listeJoueurs.keySet().toArray();
        Object key = keys[new Random().nextInt(keys.length)];
        for (Map.Entry<Integer, Joueur> entry : listeJoueurs.entrySet()) {
            sb.append(entry.getValue().afficher(null)+"\n");
            sb2.append(entry.getKey()+":Pour ce joueur\n");
        }
        System.out.println(sb.toString()+"\n"+sb2.toString());
        System.out.println(key);

        return listeJoueurs.get(key);
    }

    @Override
    public int choisirAccessoireAdv() {
        return new Random().nextInt(2);
    }

    @Override
    public int choisirPosAccessoirePassePasse() {
        return new Random().nextInt(3);
    }
}
