import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class EasyLevel implements LevelStrategy {
    @Override
    public int choisirTour() {
        return 0;
    }

    @Override
    public int choisirSaCarteAEchanger() {
        return 0;
    }

    @Override
    public Joueur choisirAdv(HashMap<Integer,Joueur> listeJoueurs) {
        StringBuffer sb = new StringBuffer();
        StringBuffer sb2 = new StringBuffer();
        Object[] keys = listeJoueurs.keySet().toArray();
        Object key = keys[new Random().nextInt(keys.length)];
        for (Map.Entry<Integer, Joueur> entry : listeJoueurs.entrySet()) {
            sb.append(entry.getValue().afficher(null)+"\n");
            sb2.append(entry.getKey()+":Pour ce joueur\n");
        }
        System.out.println(sb.toString()+"\n"+sb2.toString());
        System.out.println(key);

        return listeJoueurs.get(key);
    }

    @Override
    public int choisirAccessoireAdv() {
        return 0;
    }

    @Override
    public int choisirPosAccessoirePassePasse() {
      return 0;
    }
}
