import java.util.HashMap;

public interface LevelStrategy {
     public int choisirTour();

     public int choisirSaCarteAEchanger();

     public Joueur choisirAdv(HashMap<Integer,Joueur> listeJoueurs);

     public int choisirAccessoireAdv();

     public int choisirPosAccessoirePassePasse();
}
