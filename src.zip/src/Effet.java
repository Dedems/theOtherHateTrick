public enum Effet {
    CHANGEMENT_SENS("Change de sens"),
    INTERDICTION("Interdit le prochain joueur de jouer"),
    PENALITE_SCORE("-2 au prochain joueur"),
    FIN("Termine la partie");

    private String desc;

    private Effet(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return this.desc;
    }
}
