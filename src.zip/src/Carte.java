import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Carte {

    protected String nom;
    protected String img;
    protected boolean visible;

    public Carte(String nom, String img, boolean visible) {
        this.nom = nom;
        this.img = img;
        this.visible = visible;
    }

    public Carte(String nom) {
        this.nom = nom;
        this.img = "";
        this.visible = false;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean retourner() {
        this.visible = !this.visible;
        return this.visible;
    }

    @Override
    public String toString() {
        return "[" + nom + "]";
    }

    public static ArrayList<LinkedList<Carte>> loads(boolean extension) {
        ArrayList<LinkedList<Carte>> jeuDeCartes = new ArrayList<LinkedList<Carte>>();
        LinkedList<Carte> jeuAccessoire = new LinkedList<Carte>();
        LinkedList<Carte> jeuTour = new LinkedList<Carte>();
        final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        String path = (extension ? "src/CardExtend.xml" : "src/Cards.xml");

        try {
            final DocumentBuilder builder = factory.newDocumentBuilder();
            final Document document = builder.parse(new File(path));
            final Element racine = document.getDocumentElement();
            final NodeList props = racine.getElementsByTagName("prop");
            final int nbProps = props.getLength();
            final NodeList tricks = racine.getElementsByTagName("trick");
            final int nbTricks = tricks.getLength();

            for (int i = 0; i<nbProps; i++) {
                if(props.item(i).getNodeType() == Node.ELEMENT_NODE) {
                    final Element prop = (Element) props.item(i);
                    jeuAccessoire.add(new Accessoire(prop.getAttribute("name")));
//	        		System.out.println("\n*************Accessoire************");
//	        		System.out.println("nom : " + prop.getAttribute("name"));
                }
            }

            for (int i = 0; i< nbTricks; i++) {
                if(tricks.item(i).getNodeType() == Node.ELEMENT_NODE) {
                    final Element trick = (Element) tricks.item(i);
                    final NodeList combis = trick.getElementsByTagName("combi");
                    final int nbCombis = combis.getLength();

//	        		System.out.println("\n*************Tour************");
//	        		System.out.println("nom "+i+" : " + trick.getAttribute("name"));
//	        		System.out.println("pts "+i+" : " + trick.getAttribute("point"));

                    ArrayList<String[]> combinaisons = new ArrayList<String[]>();

                    for (int j = 0; j< nbCombis; j++) {
                        final Element combi = (Element) combis.item(j);
//	        			System.out.println("combi "+j+" : " + combi.getTextContent());
                        String[] combiValeur = combi.getTextContent().split("\\|");
//	        			System.out.println(Arrays.toString(combiValeur));
                        combinaisons.add(combiValeur);
                    }

                    jeuTour.add(new Tour(combinaisons, Integer.parseInt(trick.getAttribute("point")), trick.getAttribute("name"), trick.getAttribute("effet")));
                }
            }
        } catch (final ParserConfigurationException e) {
            e.printStackTrace();
        } catch (final SAXException e) {
            e.printStackTrace();
        }  catch (final IOException e) {
            e.printStackTrace();
        }

        jeuDeCartes.add(jeuTour);
        jeuDeCartes.add(jeuAccessoire);

        return jeuDeCartes;
    }
}
