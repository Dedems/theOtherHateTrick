import java.util.HashMap;

public class Bot extends Joueur {

	private LevelStrategy difficulte;

//	public Bot(String nom) {
//		super((int) (Math.random() * 100), nom);
//		this.difficulte = new EasyLevel();
//	}

	public Bot(String nom, int level) {
		super((int) (Math.random() * (100 - 10) + 10), nom);
		LevelStrategy levelS;
		switch (level) {
			case 1:
				levelS = new EasyLevel();
				break;
			//case 3:
			//	levelS = new HardLevel();
			//	break;
			default:
				levelS = new MediumLevel();
				break;
		}
		this.difficulte = levelS;
	}

	@Override
	public int choisirTour() {
		int res = this.difficulte.choisirTour();
		System.out.println(this.getNom() + " voulez vous jouer le tour visible ? Oui:0 | Non:1");
		this.simulerReflexion();
		System.out.println(res);

		return res;
	}

	@Override
	public int choisirSaCarteAEchanger() {
		int res = this.difficulte.choisirSaCarteAEchanger();
		System.out.println(this.getNom() + " laquelle de vos cartes voulez vous échanger ? Gauche:0 | Droite:1");
		this.simulerReflexion();
		System.out.println(res);

		return res;
	}

	@Override
	public Joueur choisirAdv(HashMap<Integer, Joueur> listeJoueurs) {
		System.out.println(this.getNom() + " avec qui voulez vous echanger votre carte ?\n ");
		this.simulerReflexion();
		Joueur j = this.difficulte.choisirAdv(listeJoueurs);

		return j;
	}

	@Override
	public int choisirAccessoireAdv(String nomAdv) {
		int res = this.difficulte.choisirAccessoireAdv();
		System.out.println("Quelle carte de " + nomAdv + " voulez vous échanger avec la votre ? Gauche:0 | Droite:1");
		this.simulerReflexion();
		System.out.println(res);

		return res;
	}

	@Override
	public int choisirPosAccessoirePassePasse() {
		int res = this.difficulte.choisirPosAccessoirePassePasse();
		System.out.println("Veuillez choisir la carte à mettre au centre parmis vos deux accessoires\n" +
				"et la carte du millieu afficher ci-dessus. Votre carte Gauche:0 | Droite:1 | Milieu:2");
		this.simulerReflexion();
		System.out.println(res);

		return res;
	}

	@Override
	public void subirPenalite() {
		System.out.println("Vous n'avez malheuresement pas réussi de tour de magie, "+this.getNom()+"\n");
		if (!this.getMain().get(0).isVisible() && !this.getMain().get(1).isVisible()) {
			System.out.println("veuillez choisir une de vos carte à rendre visible. Gauche:0 | Droite:1");
			this.simulerReflexion();
			System.out.println("0");
			this.getMain().get(0).retourner();
		} else if (this.getMain().get(0).isVisible() && !this.getMain().get(1).isVisible()) {
			System.out.println("Votre carte gauche étant visible, votre carte droite est retournée.");
			this.getMain().get(1).retourner();
		} else if (!this.getMain().get(0).isVisible() && this.getMain().get(1).isVisible()) {
			System.out.println("Votre carte droite étant visible, votre carte gauche est retournée.");
			this.getMain().get(0).retourner();
		} else {
			System.out.println("Vos deux cartes étant visibles, pas de pénalité supplémentaire.");
		}
	}

	private void simulerReflexion() {
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	//TODO: Override afficher(Joueur j) pour afficher la main du bot comme ça -> [######, ######]
}
