import java.util.HashMap;
import java.util.Random;

//TODO: Level Hard
public class HardLevel implements LevelStrategy {
    @Override
    public int choisirTour() {
        return 0;
    }

    @Override
    public int choisirSaCarteAEchanger() {
        return 0;
    }

    @Override
    public Joueur choisirAdv(HashMap<Integer,Joueur> listeJoueurs) {
        Object[] keys = listeJoueurs.keySet().toArray();
        Object key = keys[new Random().nextInt(keys.length)];

        return listeJoueurs.get(key);
    }

    @Override
    public int choisirAccessoireAdv() {
        return 0;
    }

    @Override
    public int choisirPosAccessoirePassePasse() {
        return 0;
    }
}
