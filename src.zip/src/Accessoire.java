
public class Accessoire extends Carte {

	public Accessoire(String nom, String img, boolean visibilite) {
		super(nom, img, visibilite);
	}
	
	public Accessoire(String nom) {
		super(nom);
	}

	@Override
	public String toString() {
		return this.nom;
	}
}
